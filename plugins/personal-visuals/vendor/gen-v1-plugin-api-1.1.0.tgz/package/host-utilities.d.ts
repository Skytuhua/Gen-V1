export interface ProfileLease {dataDir:string;close():void}
export declare function acquireProfileLease(directory:string):ProfileLease;
