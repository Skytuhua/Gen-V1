# Gen plug-in API v1

PluginManifest, ConversationAdapter and PluginSurface are the public data contracts. Hosts export default {activate({dataDir,genVersion})}. The context contains no personal Store, runtime, account or credential manager. Frontends run in an opaque sandbox and share GenPluginUI presentation components; all operations cross its source-checked bridge. Host utilities provide single-writer profile leasing. Package installation requires a trusted SHA-256 inventory digest. See the public Gen plug-in guide for the full package format.
