import { z } from 'zod';
export declare const pluginIdSchema: z.ZodString;
export declare const pluginVersionSchema: z.ZodString;
export declare const pluginWorkspaceContributionSchema: z.ZodObject<{
    id: z.ZodString;
    title: z.ZodString;
    icon: z.ZodOptional<z.ZodString>;
    entryView: z.ZodString;
    defaultLayout: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type PluginWorkspaceContribution = z.infer<typeof pluginWorkspaceContributionSchema>;
export declare const pluginWorkspacesSchema: z.ZodArray<z.ZodObject<{
    id: z.ZodString;
    title: z.ZodString;
    icon: z.ZodOptional<z.ZodString>;
    entryView: z.ZodString;
    defaultLayout: z.ZodOptional<z.ZodString>;
}, z.core.$strict>>;
export declare const pluginPathSchema: z.ZodString;
export declare const pluginManifestSchema: z.ZodObject<{
    id: z.ZodString;
    name: z.ZodString;
    version: z.ZodString;
    apiVersion: z.ZodLiteral<1>;
    compatibleGenVersions: z.ZodString;
    frontendEntry: z.ZodString;
    hostEntry: z.ZodString;
    workspaces: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        title: z.ZodString;
        icon: z.ZodOptional<z.ZodString>;
        entryView: z.ZodString;
        defaultLayout: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>>;
}, z.core.$strict>;
export type PluginManifest = z.infer<typeof pluginManifestSchema>;
export declare const pluginSurfaceSchema: z.ZodObject<{
    kind: z.ZodLiteral<"plugin">;
    pluginId: z.ZodString;
    scopeId: z.ZodString;
    surfaceId: z.ZodString;
    resourceId: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type PluginSurface = z.infer<typeof pluginSurfaceSchema>;
export type Capability = {
    available: true;
} | {
    available: false;
    reason: string;
};
export interface ConversationRef {
    pluginId: string;
    scopeId: string;
    conversationId: string;
}
export interface ConversationMessage {
    id: string;
    role: 'user' | 'assistant' | 'system';
    content: string;
}
export interface ConversationView {
    ref: ConversationRef;
    title: string;
    messages: ConversationMessage[];
    capabilities: {
        send: Capability;
        submitArtifactAction: Capability;
        cancel: Capability;
    };
}
export interface MessageInput {
    content: string;
    requestId: string;
}
export interface ArtifactActionInput {
    artifactId: string;
    actionId: string;
    revision: number;
    payload: unknown;
    requestId: string;
}
export interface ConversationAdapter {
    load(ref: ConversationRef, signal: AbortSignal): Promise<ConversationView>;
    send(ref: ConversationRef, input: MessageInput, signal: AbortSignal): Promise<unknown>;
    submitArtifactAction(ref: ConversationRef, input: ArtifactActionInput, signal: AbortSignal): Promise<unknown>;
    cancel(ref: ConversationRef, signal: AbortSignal): Promise<unknown>;
}
export interface PluginHostContext {
    dataDir: string;
    genVersion: string;
}
export interface PluginHostInstance {
    operations: Record<string, (input: unknown, signal: AbortSignal) => Promise<unknown>>;
    validateSurface?: (surface: PluginSurface) => Promise<boolean>;
    isBusy?: () => Promise<boolean>;
    close: () => Promise<void>;
}
/** hostEntry exports default {activate(context): Promise<PluginHostInstance>}.
 * The trusted package receives only its own persistent directory and Gen version.
 * It is trusted Node code, not an in-process security sandbox. */
export interface PluginHostModule {
    activate(context: PluginHostContext): Promise<PluginHostInstance>;
}
export interface PluginCompatibility {
    compatible: boolean;
    blockers: {
        pluginId: string;
        reason: string;
    }[];
}
