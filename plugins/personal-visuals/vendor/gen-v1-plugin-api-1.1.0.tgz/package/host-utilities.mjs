// apps/server/profile-lease.ts
import { mkdirSync, openSync, closeSync, lstatSync, realpathSync, statSync } from "node:fs";
import { join, resolve } from "node:path";
import { DatabaseSync } from "node:sqlite";

// packages/contracts/index.ts
var HarnessError = class extends Error {
  constructor(code, message, details) {
    super(message);
    this.code = code;
    this.details = details;
    this.name = "HarnessError";
  }
};

// apps/server/profile-lease.ts
function acquireProfileLease(directory) {
  if (!directory.trim()) throw new HarnessError("PROFILE_LEASE_INVALID", "The profile directory must be nonempty.");
  mkdirSync(resolve(directory), { recursive: true });
  const dataDir = realpathSync(directory), path = join(dataDir, ".host-lease.sqlite");
  const parent = statSync(dataDir, { bigint: true });
  try {
    const file = openSync(path, "wx", 384);
    closeSync(file);
  } catch (error) {
    if (error.code !== "EEXIST") throw error;
  }
  const identity = lstatSync(path, { bigint: true });
  if (!identity.isFile() || identity.isSymbolicLink() || identity.nlink !== 1n) throw new HarnessError("PROFILE_LEASE_INVALID", "The profile ownership file must be an ordinary private file.");
  let database;
  try {
    database = new DatabaseSync(path, { timeout: 0 });
    database.exec("BEGIN EXCLUSIVE");
    const acquired = lstatSync(path, { bigint: true }), currentParent = statSync(dataDir, { bigint: true });
    if (!acquired.isFile() || acquired.isSymbolicLink() || acquired.nlink !== 1n || identity.dev !== acquired.dev || identity.ino !== acquired.ino || parent.dev !== currentParent.dev || parent.ino !== currentParent.ino || realpathSync(directory) !== dataDir) throw new HarnessError("PROFILE_LEASE_INVALID", "The profile directory changed while acquiring ownership.");
  } catch (error) {
    database?.close();
    if (error.errcode === 5 || error.code === "SQLITE_BUSY") throw new HarnessError("PROFILE_IN_USE", "This profile is already open in another harness process. Close that owner before starting another host.");
    throw error;
  }
  let closed = false;
  const owned = database;
  return { dataDir, close() {
    if (closed) return;
    owned.exec("ROLLBACK");
    owned.close();
    closed = true;
  } };
}
export {
  acquireProfileLease
};
