# Motion

| screen | state | width | frame | selector | type | animationName | transitionProperty | properties | duration | delay | easing | iterations | fill |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| app-shell | default:load | 1440 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > aside:nth-child(1) > nav:nth-child(3) | CSSAnimation | shell-sidebar-in |  | ["opacity","transform"] | 220 | 0 | linear | 1 | both |
| app-shell | default | 1440 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > aside:nth-child(1) > nav:nth-child(3) | CSSAnimation | shell-sidebar-in |  | ["opacity","transform"] | 220 | 0 | linear | 1 | both |
| app-shell | default:load | 768 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > aside:nth-child(1) > nav:nth-child(3) | CSSAnimation | shell-sidebar-in |  | ["opacity","transform"] | 220 | 0 | linear | 1 | both |
| app-shell | default | 768 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > aside:nth-child(1) > nav:nth-child(3) | CSSAnimation | shell-sidebar-in |  | ["opacity","transform"] | 220 | 0 | linear | 1 | both |
| app-shell | hover:load | 768 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > aside:nth-child(1) > nav:nth-child(3) | CSSAnimation | shell-sidebar-in |  | ["opacity","transform"] | 220 | 0 | linear | 1 | both |
| app-shell | hover | 768 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > aside:nth-child(1) > nav:nth-child(3) | CSSAnimation | shell-sidebar-in |  | ["opacity","transform"] | 220 | 0 | linear | 1 | both |
| app-shell | hover | 768 | main | #_r_9_ | CSSAnimation | thread-hover-enter |  | ["opacity"] | 160 | 0 | linear | 1 | none |
| app-shell | hover | 375 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > aside:nth-child(2) | CSSTransition |  | transform | ["transform"] | 220 | 0 | ease-out | 1 | backwards |
| app-shell | hover | 375 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > aside:nth-child(2) > nav:nth-child(3) | CSSAnimation | shell-sidebar-in |  | ["opacity","transform"] | 200 | 0 | linear | 1 | both |
| app-shell | hover | 375 | main | #_r_9_ | CSSAnimation | thread-hover-enter |  | ["opacity"] | 160 | 0 | linear | 1 | none |
| app-shell | hover:load | 1440 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > aside:nth-child(1) > nav:nth-child(3) | CSSAnimation | shell-sidebar-in |  | ["opacity","transform"] | 220 | 0 | linear | 1 | both |
| app-shell | hover | 1440 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > aside:nth-child(1) > nav:nth-child(3) | CSSAnimation | shell-sidebar-in |  | ["opacity","transform"] | 220 | 0 | linear | 1 | both |
| app-shell | hover | 1440 | main | #_r_9_ | CSSAnimation | thread-hover-enter |  | ["opacity"] | 160 | 0 | linear | 1 | none |
| app-shell | focus:load | 768 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > aside:nth-child(1) > nav:nth-child(3) | CSSAnimation | shell-sidebar-in |  | ["opacity","transform"] | 220 | 0 | linear | 1 | both |
| app-shell | focus | 768 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > aside:nth-child(1) > nav:nth-child(3) | CSSAnimation | shell-sidebar-in |  | ["opacity","transform"] | 220 | 0 | linear | 1 | both |
| app-shell | focus | 768 | main | #_r_9_ | CSSAnimation | thread-hover-enter |  | ["opacity"] | 160 | 0 | linear | 1 | none |
| app-shell | focus:load | 1440 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > aside:nth-child(1) > nav:nth-child(3) | CSSAnimation | shell-sidebar-in |  | ["opacity","transform"] | 220 | 0 | linear | 1 | both |
| app-shell | focus | 1440 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > aside:nth-child(1) > nav:nth-child(3) | CSSAnimation | shell-sidebar-in |  | ["opacity","transform"] | 220 | 0 | linear | 1 | both |
| app-shell | focus | 1440 | main | #_r_9_ | CSSAnimation | thread-hover-enter |  | ["opacity"] | 160 | 0 | linear | 1 | none |
| app-shell | focus | 375 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > aside:nth-child(2) | CSSTransition |  | transform | ["transform"] | 220 | 0 | ease-out | 1 | backwards |
| app-shell | focus | 375 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > aside:nth-child(2) > nav:nth-child(3) | CSSAnimation | shell-sidebar-in |  | ["opacity","transform"] | 200 | 0 | linear | 1 | both |
| app-shell | open:load | 768 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > aside:nth-child(1) > nav:nth-child(3) | CSSAnimation | shell-sidebar-in |  | ["opacity","transform"] | 220 | 0 | linear | 1 | both |
| app-shell | open | 768 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > aside:nth-child(1) > nav:nth-child(3) | CSSAnimation | shell-sidebar-in |  | ["opacity","transform"] | 220 | 0 | linear | 1 | both |
| app-shell | open | 768 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > dialog:nth-child(4) | CSSAnimation | shell-dialog-in |  | ["opacity","transform"] | 180 | 0 | linear | 1 | both |
| app-shell | open | 768 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > dialog:nth-child(4) | CSSAnimation | shell-backdrop-in |  | ["opacity"] | 170 | 0 | linear | 1 | both |
| app-shell | open:load | 1440 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > aside:nth-child(1) > nav:nth-child(3) | CSSAnimation | shell-sidebar-in |  | ["opacity","transform"] | 220 | 0 | linear | 1 | both |
| app-shell | open | 1440 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > aside:nth-child(1) > nav:nth-child(3) | CSSAnimation | shell-sidebar-in |  | ["opacity","transform"] | 220 | 0 | linear | 1 | both |
| app-shell | open | 1440 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > dialog:nth-child(4) | CSSAnimation | shell-dialog-in |  | ["opacity","transform"] | 180 | 0 | linear | 1 | both |
| app-shell | open | 1440 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > dialog:nth-child(4) | CSSAnimation | shell-backdrop-in |  | ["opacity"] | 170 | 0 | linear | 1 | both |
| app-shell | open | 375 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > aside:nth-child(2) | CSSTransition |  | transform | ["transform"] | 220 | 0 | ease-out | 1 | backwards |
| app-shell | open | 375 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > aside:nth-child(2) > nav:nth-child(3) | CSSAnimation | shell-sidebar-in |  | ["opacity","transform"] | 200 | 0 | linear | 1 | both |
| app-shell | open | 375 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > dialog:nth-child(4) | CSSAnimation | shell-dialog-in |  | ["opacity","transform"] | 180 | 0 | linear | 1 | both |
| app-shell | open | 375 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > dialog:nth-child(4) | CSSAnimation | shell-backdrop-in |  | ["opacity"] | 170 | 0 | linear | 1 | both |
| app-shell | empty:load | 1440 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > aside:nth-child(1) > nav:nth-child(3) | CSSAnimation | shell-sidebar-in |  | ["opacity","transform"] | 220 | 0 | linear | 1 | both |
| app-shell | empty | 1440 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > aside:nth-child(1) > nav:nth-child(3) | CSSAnimation | shell-sidebar-in |  | ["opacity","transform"] | 220 | 0 | linear | 1 | both |
| app-shell | empty:load | 768 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > aside:nth-child(1) > nav:nth-child(3) | CSSAnimation | shell-sidebar-in |  | ["opacity","transform"] | 220 | 0 | linear | 1 | both |
| app-shell | empty | 768 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > aside:nth-child(1) > nav:nth-child(3) | CSSAnimation | shell-sidebar-in |  | ["opacity","transform"] | 220 | 0 | linear | 1 | both |
