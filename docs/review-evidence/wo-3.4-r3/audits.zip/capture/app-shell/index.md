# UI capture

| screens | screenshots | identicalToDefault | motionRows | uniqueAnimations | strips | reducedMotionOffendersUnique | reducedMotionOffendersTotal |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 21 | 0 | 37 | 6 | 6 | 0 | 0 |

Runtime: 8s. Readiness reloads: 0.

## Coverage matrix

Cells list captured widths. U = unsupported/explicit exclusion; E = empty recipe; I = identical to default; F = state action failure; L = screen load failure. Codes are followed by viewport width. Full reasons below and in manifest.json.

| screen | default | hover | focus | open | empty | error | loading |
| --- | --- | --- | --- | --- | --- | --- | --- |
| app-shell | 375,768,1440 | 375,768,1440 | 375,768,1440 | 375,768,1440 | 375,768,1440 | 375,768,1440 | 375,768,1440 |

Native desktop surfaces are not captured by the web harness.

[Scope](scope.md) · [Motion](motion.md) · [Reduced motion](reduced-motion.md) · [Manifest](manifest.json)

## Output checks

Passed. Iframe motion/strip/reduced-motion evidence and required state/width outcomes are complete.

## Failures

_None._

## State outcomes and skipped reasons

| screen | state | width | reduced | status | path | reason |
| --- | --- | --- | --- | --- | --- | --- |
| app-shell | default | 1440 | false | captured | screenshots/app-shell/default-1440.png |  |
| app-shell | default | 375 | false | captured | screenshots/app-shell/default-375.png |  |
| app-shell | default | 768 | false | captured | screenshots/app-shell/default-768.png |  |
| app-shell | hover | 768 | false | captured | screenshots/app-shell/hover-768.png |  |
| app-shell | hover | 375 | false | captured | screenshots/app-shell/hover-375.png |  |
| app-shell | hover | 1440 | false | captured | screenshots/app-shell/hover-1440.png |  |
| app-shell | focus | 768 | false | captured | screenshots/app-shell/focus-768.png |  |
| app-shell | focus | 1440 | false | captured | screenshots/app-shell/focus-1440.png |  |
| app-shell | focus | 375 | false | captured | screenshots/app-shell/focus-375.png |  |
| app-shell | open | 768 | false | captured | screenshots/app-shell/open-768.png |  |
| app-shell | open | 1440 | false | captured | screenshots/app-shell/open-1440.png |  |
| app-shell | open | 375 | false | captured | screenshots/app-shell/open-375.png |  |
| app-shell | empty | 1440 | false | captured | screenshots/app-shell/empty-1440.png |  |
| app-shell | empty | 768 | false | captured | screenshots/app-shell/empty-768.png |  |
| app-shell | empty | 375 | false | captured | screenshots/app-shell/empty-375.png |  |
| app-shell | error | 768 | false | captured | screenshots/app-shell/error-768.png |  |
| app-shell | error | 1440 | false | captured | screenshots/app-shell/error-1440.png |  |
| app-shell | error | 375 | false | captured | screenshots/app-shell/error-375.png |  |
| app-shell | loading | 768 | false | captured | screenshots/app-shell/loading-768.png |  |
| app-shell | loading | 1440 | false | captured | screenshots/app-shell/loading-1440.png |  |
| app-shell | loading | 375 | false | captured | screenshots/app-shell/loading-375.png |  |

## Frame strips

| screen | state | width | frame | selector | motionKey | path | status |
| --- | --- | --- | --- | --- | --- | --- | --- |
| app-shell | default | 1440 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > aside:nth-child(1) > nav:nth-child(3) | ["app-shell","main","body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > aside:nth-child(1) > nav:nth-child(3)","CSSAnimation","shell-sidebar-in","",["opacity","transform"],220,0,"linear",1,"both",[{"offset":0,"easing":"cubic-bezier(0.16, 1, 0.3, 1)","composite":"auto","opacity":"0.45","transform":"translate(-5px)","computedOffset":0},{"offset":1,"easing":"cubic-bezier(0.16, 1, 0.3, 1)","composite":"auto","opacity":"1","transform":"none","computedOffset":1}]] | strips/001-app-shell.png | captured |
| app-shell | hover | 768 | main | #_r_9_ | ["app-shell","main","#_r_9_","CSSAnimation","thread-hover-enter","",["opacity"],160,0,"linear",1,"none",[{"offset":0,"easing":"cubic-bezier(0.16, 1, 0.3, 1)","composite":"auto","opacity":"1","computedOffset":0},{"offset":1,"easing":"cubic-bezier(0.16, 1, 0.3, 1)","composite":"auto","opacity":"1","computedOffset":1}]] | strips/002-app-shell.png | captured |
| app-shell | hover | 375 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > aside:nth-child(2) | ["app-shell","main","body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > aside:nth-child(2)","CSSTransition","","transform",["transform"],220,0,"ease-out",1,"backwards",[{"offset":0,"easing":"linear","composite":"auto","transform":"translate(-100%)","computedOffset":0},{"offset":1,"easing":"linear","composite":"auto","transform":"translate(0px)","computedOffset":1}]] | strips/003-app-shell.png | captured |
| app-shell | hover | 375 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > aside:nth-child(2) > nav:nth-child(3) | ["app-shell","main","body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > aside:nth-child(2) > nav:nth-child(3)","CSSAnimation","shell-sidebar-in","",["opacity","transform"],200,0,"linear",1,"both",[{"offset":0,"easing":"cubic-bezier(0.16, 1, 0.3, 1)","composite":"auto","opacity":"0.45","transform":"translate(-5px)","computedOffset":0},{"offset":1,"easing":"cubic-bezier(0.16, 1, 0.3, 1)","composite":"auto","opacity":"1","transform":"none","computedOffset":1}]] | strips/004-app-shell.png | captured |
| app-shell | open | 1440 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > dialog:nth-child(4) | ["app-shell","main","body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > dialog:nth-child(4)","CSSAnimation","shell-backdrop-in","",["opacity"],170,0,"linear",1,"both",[{"offset":0,"easing":"ease-out","composite":"auto","opacity":"0","computedOffset":0},{"offset":1,"easing":"ease-out","composite":"auto","opacity":"1","computedOffset":1}]] | strips/006-app-shell.png | captured |
| app-shell | open | 768 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > dialog:nth-child(4) | ["app-shell","main","body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > dialog:nth-child(4)","CSSAnimation","shell-dialog-in","",["opacity","transform"],180,0,"linear",1,"both",[{"offset":0,"easing":"cubic-bezier(0.16, 1, 0.3, 1)","composite":"auto","opacity":"0.4","transform":"scale(0.95)","computedOffset":0},{"offset":1,"easing":"cubic-bezier(0.16, 1, 0.3, 1)","composite":"auto","opacity":"1","transform":"none","computedOffset":1}]] | strips/005-app-shell.png | captured |
