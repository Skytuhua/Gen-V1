# UI capture

| screens | screenshots | identicalToDefault | motionRows | uniqueAnimations | strips | reducedMotionOffendersUnique | reducedMotionOffendersTotal |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 21 | 0 | 101 | 4 | 4 | 0 | 0 |

Runtime: 3s. Readiness reloads: 0.

## Coverage matrix

Cells list captured widths. U = unsupported/explicit exclusion; E = empty recipe; I = identical to default; F = state action failure; L = screen load failure. Codes are followed by viewport width. Full reasons below and in manifest.json.

| screen | default | hover | focus | open | empty | error | loading |
| --- | --- | --- | --- | --- | --- | --- | --- |
| sidebar-menu | 375,768,1440 | 375,768,1440 | 375,768,1440 | 375,768,1440 | 375,768,1440 | 375,768,1440 | 375,768,1440 |

Native desktop surfaces are not captured by the web harness.

[Scope](scope.md) · [Motion](motion.md) · [Reduced motion](reduced-motion.md) · [Manifest](manifest.json)

## Output checks

Passed. Iframe motion/strip/reduced-motion evidence and required state/width outcomes are complete.

## Failures

_None._

## State outcomes and skipped reasons

| screen | state | width | reduced | status | path | reason |
| --- | --- | --- | --- | --- | --- | --- |
| sidebar-menu | default | 375 | false | captured | screenshots/sidebar-menu/default-375.png |  |
| sidebar-menu | default | 768 | false | captured | screenshots/sidebar-menu/default-768.png |  |
| sidebar-menu | default | 1440 | false | captured | screenshots/sidebar-menu/default-1440.png |  |
| sidebar-menu | hover | 768 | false | captured | screenshots/sidebar-menu/hover-768.png |  |
| sidebar-menu | hover | 1440 | false | captured | screenshots/sidebar-menu/hover-1440.png |  |
| sidebar-menu | hover | 375 | false | captured | screenshots/sidebar-menu/hover-375.png |  |
| sidebar-menu | focus | 768 | false | captured | screenshots/sidebar-menu/focus-768.png |  |
| sidebar-menu | focus | 1440 | false | captured | screenshots/sidebar-menu/focus-1440.png |  |
| sidebar-menu | focus | 375 | false | captured | screenshots/sidebar-menu/focus-375.png |  |
| sidebar-menu | open | 1440 | false | captured | screenshots/sidebar-menu/open-1440.png |  |
| sidebar-menu | open | 768 | false | captured | screenshots/sidebar-menu/open-768.png |  |
| sidebar-menu | empty | 1440 | false | captured | screenshots/sidebar-menu/empty-1440.png |  |
| sidebar-menu | open | 375 | false | captured | screenshots/sidebar-menu/open-375.png |  |
| sidebar-menu | empty | 768 | false | captured | screenshots/sidebar-menu/empty-768.png |  |
| sidebar-menu | empty | 375 | false | captured | screenshots/sidebar-menu/empty-375.png |  |
| sidebar-menu | error | 1440 | false | captured | screenshots/sidebar-menu/error-1440.png |  |
| sidebar-menu | error | 768 | false | captured | screenshots/sidebar-menu/error-768.png |  |
| sidebar-menu | loading | 1440 | false | captured | screenshots/sidebar-menu/loading-1440.png |  |
| sidebar-menu | error | 375 | false | captured | screenshots/sidebar-menu/error-375.png |  |
| sidebar-menu | loading | 768 | false | captured | screenshots/sidebar-menu/loading-768.png |  |
| sidebar-menu | loading | 375 | false | captured | screenshots/sidebar-menu/loading-375.png |  |

## Frame strips

| screen | state | width | frame | selector | motionKey | path | status |
| --- | --- | --- | --- | --- | --- | --- | --- |
| sidebar-menu | default | 768 | main | nav:nth-child(3) > div:nth-child(1) > div:nth-child(2) > button:nth-child(1) > span:nth-child(1) > span:nth-child(2) > span:nth-child(1) > svg:nth-child(1) | ["sidebar-menu","main","nav:nth-child(3) > div:nth-child(1) > div:nth-child(2) > button:nth-child(1) > span:nth-child(1) > span:nth-child(2) > span:nth-child(1) > svg:nth-child(1)","CSSAnimation","spin","",["transform"],1000,0,"linear","Infinity","none",[{"offset":0,"easing":"linear","composite":"replace","transform":"none","computedOffset":0},{"offset":1,"easing":"linear","composite":"auto","transform":"rotate(360deg)","computedOffset":1}]] | strips/001-sidebar-menu.png | captured |
| sidebar-menu | default | 1440 | main | nav:nth-child(3) > div:nth-child(1) > div:nth-child(3) > button:nth-child(1) > span:nth-child(1) > span:nth-child(2) > span:nth-child(1) > svg:nth-child(1) | ["sidebar-menu","main","nav:nth-child(3) > div:nth-child(1) > div:nth-child(3) > button:nth-child(1) > span:nth-child(1) > span:nth-child(2) > span:nth-child(1) > svg:nth-child(1)","CSSAnimation","spin","",["transform"],1000,0,"linear","Infinity","none",[{"offset":0,"easing":"linear","composite":"replace","transform":"none","computedOffset":0},{"offset":1,"easing":"linear","composite":"auto","transform":"rotate(360deg)","computedOffset":1}]] | strips/003-sidebar-menu.png | captured |
| sidebar-menu | default | 375 | main | body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > aside:nth-child(1) > nav:nth-child(3) | ["sidebar-menu","main","body:nth-child(2) > div:nth-child(1) > div:nth-child(1) > aside:nth-child(1) > nav:nth-child(3)","CSSAnimation","shell-sidebar-in","",["opacity","transform"],200,0,"linear",1,"both",[{"offset":0,"easing":"cubic-bezier(0.16, 1, 0.3, 1)","composite":"auto","opacity":"0.45","transform":"translate(-5px)","computedOffset":0},{"offset":1,"easing":"cubic-bezier(0.16, 1, 0.3, 1)","composite":"auto","opacity":"1","transform":"none","computedOffset":1}]] | strips/002-sidebar-menu.png | captured |
| sidebar-menu | focus | 768 | main | #_r_0_ | ["sidebar-menu","main","#_r_0_","CSSAnimation","thread-hover-enter","",["opacity"],160,0,"linear",1,"none",[{"offset":0,"easing":"cubic-bezier(0.16, 1, 0.3, 1)","composite":"auto","opacity":"1","computedOffset":0},{"offset":1,"easing":"cubic-bezier(0.16, 1, 0.3, 1)","composite":"auto","opacity":"1","computedOffset":1}]] | strips/004-sidebar-menu.png | captured |
