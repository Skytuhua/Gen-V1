from pathlib import Path
import subprocess,os,json,re

root=Path('/home/box/work/Gen-V1-wo-3-4');out=Path('/home/box/gen-company/ledger/WO-3/qa-r3-3.4/baseline')
native=Path('/tmp/wo-3-118-r3-prereqs/node_modules/node-pty')
assert (native/'build/Release/pty.node').is_file()
assert json.loads((native/'package.json').read_text())['version']=='1.1.0'
specs=Path('/home/box/work/base-failing-files.txt').read_text().splitlines()
env={**os.environ,'COREPACK_HOME':str(Path.home()/'.cache/corepack')}
results={}
for name in ['head','main']:
    checkout=Path('/tmp')/f'wo-3-118-r3-baseline-{name}'
    modules=checkout/'node_modules';shared=(root/'node_modules').resolve()
    if modules.is_symlink():modules.unlink();modules.mkdir()
    else:
        assert modules.is_dir()
        aliases=list(modules.iterdir());assert all(p.is_symlink() for p in aliases)
        for alias in aliases:alias.unlink()
    for entry in shared.iterdir():
        (modules/entry.name).symlink_to(native if entry.name=='node-pty' else entry,target_is_directory=entry.is_dir())
    assert (checkout/'dist/widget-runtime/receiver.js').is_file()
    command=['timeout','240s','pnpm','exec','vitest','run',*specs,'--maxWorkers=1','--configLoader','runner','--reporter=default','--reporter=json',f'--outputFile={out}/prepared-{name}.json']
    print(name,'running built widgets and authentic compiled node-pty 1.1.0',flush=True)
    with (out/f'prepared-{name}.log').open('w') as log:run=subprocess.run(command,cwd=checkout,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=260)
    file=out/f'prepared-{name}.json'
    if not file.exists():
        results[name]={'exitCode':run.returncode,'reportMissing':True};continue
    report=json.loads(file.read_text());failed=set();blocked=[];guard=[];platform=[]
    for entry in report['testResults']:
        path=str(Path(entry['name']).relative_to(checkout))
        if not entry.get('assertionResults'):
            blocked.append({'file':path,'message':entry.get('message','')});failed.add(path+' :: [collection error]')
        for test in entry.get('assertionResults',[]):
            if test['status']!='failed':continue
            identity=path+' :: '+test['fullName'];failed.add(identity);messages='\n'.join(test['failureMessages'])
            if 'Cannot establish a stable ordinary filesystem resource guard' in messages:guard.append(identity)
            if '@cursor/sdk-win32-x64' in messages:platform.append(identity)
    results[name]={'exitCode':run.returncode,'totalFiles':len(report['testResults']),'collectedFiles':len(report['testResults'])-len(blocked),
        'totalTests':report['numTotalTests'],'failedTests':report['numFailedTests'],'passedTests':report['numPassedTests'],'pendingTests':report['numPendingTests'],
        'collectionBlocked':blocked,'guardBlockedTestIdentities':guard,'windowsPackageBlockedTestIdentities':platform,'failedIdentities':sorted(failed)}
    print(name,json.dumps({k:v for k,v in results[name].items() if k in ['exitCode','totalFiles','collectedFiles','totalTests','failedTests','passedTests','pendingTests']}),flush=True)
if all('failedIdentities' in results.get(name,{}) for name in ['head','main']):
    new=set(results['head']['failedIdentities'])-set(results['main']['failedIdentities'])
    results['comparison']={'newFailedIdentities':sorted(new),'newFailureCount':len(new),'allFilesCollected':all(r['collectedFiles']==58 for r in [results['head'],results['main']]),
        'functioningSecurityBoundary':False,'limitation':'Real Linux guard is not available in this sandbox (no trusted broker FD3/FD4 and incompatible uid_map); no mocks, disables or test exclusions used.'}
(out/'prepared-comparison.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results.get('comparison',{})),flush=True)
