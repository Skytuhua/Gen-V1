from pathlib import Path
from PIL import Image,ImageDraw,ImageFont,ImageChops
import json,hashlib,zipfile

root=Path('/home/box/work/Gen-V1-wo-3-4');out=Path('/home/box/gen-company/ledger/WO-3/qa-r3-3.4')
packet=root/'docs/review-evidence/wo-3.4-r3';packet.mkdir(parents=True,exist_ok=True)
head=json.loads((out/'web-quality/results.json').read_text());main=json.loads((out/'main/web-quality/results.json').read_text())
baseline=json.loads((out/'baseline/prepared-comparison.json').read_text())
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',18)
strips=[]
for motion in head['motion']:
 if motion['width']!=1440:continue
 images=[Image.open(f['file']).convert('RGB') for f in motion['frames']]
 deltas=[max(v[1] for v in ImageChops.difference(a,b).getextrema()) for a,b in zip(images,images[1:])];assert all(deltas)
 band=images[0].height+44;sheet=Image.new('RGB',(1440,band*3),'#111318');draw=ImageDraw.Draw(sheet)
 for i,(frame,image) in enumerate(zip(motion['frames'],images)):
  draw.text((12,i*band+8),f"Move to {motion['edge']}: {frame['ms']} ms / 180 ms",font=font,fill='white');sheet.paste(image,(0,i*band+36))
 name=f"move-{motion['edge']}.png";sheet.save(packet/name,optimize=True)
 strips.append({'edge':motion['edge'],'times':[f['ms'] for f in motion['frames']],'adjacentMaxChannelDelta':deltas,'pixelHashes':[hashlib.sha256(im.tobytes()).hexdigest() for im in images]})
manifests={screen:json.loads((out/f'captures/{screen}/manifest.json').read_text()) for screen in ['app-shell','sidebar-menu']}
for width in [375,768,1440]:
 entries=[(screen,e) for screen,m in manifests.items() for e in m['entries'] if e['width']==width]
 assert len(entries)==14 and all(e['status']=='captured' for _,e in entries)
 images=[Image.open(out/f'captures/{screen}'/e['path']).convert('RGB') for screen,e in entries]
 w=max(im.width for im in images);h=max(im.height for im in images)+40;sheet=Image.new('RGB',(w*3,h*5),'#111318');draw=ImageDraw.Draw(sheet)
 for i,((screen,e),im) in enumerate(zip(entries,images)):
  x=(i%3)*w;y=(i//3)*h;draw.text((x+8,y+8),f"{screen}/{e['state']}/{width}",font=font,fill='white');sheet.paste(im,(x,y+40))
 sheet.save(packet/f'states-{width}.png',optimize=True)
fingerprint=lambda r:[{'width':a['width'],'state':a['state'],'status':a['status'],'violations':[{'id':v['id'],'nodes':len(v['nodes'])} for v in a.get('violations',[])]} for a in r['axe']]
summary={'measuredHead':head['head'],'main':main['head'],'runtimeFix':'71101ef2b224014a672a402f492bc4c7fe757182',
 'baseline':baseline,'captureCommands':head['commands'],'strips':strips,'axeHead':fingerprint(head),'axeMain':fingerprint(main),
 'matchingAxeFingerprints':fingerprint(head)==fingerprint(main),'headLighthouse':head['lighthouse'],'mainLighthouse':main['lighthouse'],
 'headLayout':head['layout'],'mainLayout':main['layout'],'headAuditExitCode':head['exitCode'],'mainAuditExitCode':main['exitCode'],
 'nativePrerequisite':json.loads((out/'baseline/prerequisites-repaired.json').read_text()),
 'kernelPrerequisites':json.loads((out/'baseline/kernel-prerequisites.json').read_text()),
 'finiteHostCheck':json.loads((out/'finite-host-check.json').read_text()),
 'runtimeSha256':{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in ['apps/web/src/App.tsx','apps/web/src/ComposerView.tsx','apps/web/src/ShellSidebar.tsx','apps/web/src/sidebar-thread-move.ts','apps/web/src/sidebar-thread-move.css','packages/ui-shell/tokens.css','tests/e2e/thread-move.spec.ts','tests/e2e/thread-move-fixture.tsx']}}
(packet/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
with zipfile.ZipFile(packet/'audits.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for group,folder in [('head',out/'web-quality'),('main',out/'main/web-quality')]:
  for file in folder.iterdir():
   if file.is_file():z.write(file,f'{group}/{file.name}')
 for file in [out/'baseline/prepared-comparison.json',out/'baseline/prepared-head.json',out/'baseline/prepared-main.json',out/'baseline/kernel-prerequisites.json',out/'baseline/prerequisites-repaired.json',out/'feature-map-before.json',out/'feature-map-after.json',out/'finite-host-check.json']:
  z.write(file,'evidence/'+file.name)
 for screen in manifests:
  for name in ['manifest.json','motion.md','reduced-motion.md','index.md']:z.write(out/f'captures/{screen}'/name,f'capture/{screen}/{name}')
 for name in ['node-pty-build-final.log','final-typecheck-diagnostic.log','final-lint-ui.log','final-focused-vitest.log','final-verify-ui.log','capture-app-shell.log','capture-sidebar-menu.log','prepared-baseline-final.log','web-quality.log','main-web-quality.log']:
  file=out/'logs'/name
  if file.is_file():z.write(file,'logs/'+name)
 for name in ['static-host.mjs','web-quality.mjs','prepared-baseline.py','packet.py']:
  file=Path('/home/box/gen-company/ledger/WO-3/scratch/3.4/r3')/name;z.write(file,'reproduce/'+name)
print(json.dumps({'files':{p.name:p.stat().st_size for p in packet.iterdir()},'allBaselineFilesCollected':baseline['comparison']['allFilesCollected'],'axeFingerprintsMatch':summary['matchingAxeFingerprints'],'strips':strips},indent=2))
