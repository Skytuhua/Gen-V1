import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
import {createServer} from 'node:http';
import {readFile} from 'node:fs/promises';
import {resolve,extname} from 'node:path';

export async function startHost(root,name,port){
 const require=createRequire('/home/box/work/Gen-V1-wo-3-4/package.json');
 const {build}=await import(pathToFileURL(require.resolve('vite')));
 const {shellSnapshot,shellRoute,shellInit}=await import(pathToFileURL(`${root}/scripts/capture-ui/shell-api.ts`));
 const dist=`/tmp/wo-3-118-r3-static-${name}`;
 await build({configFile:`${root}/vite.config.ts`,configLoader:'runner',root:`${root}/apps/web`,
  build:{outDir:dist,emptyOutDir:true,watch:null,manifest:true,rollupOptions:{input:{app:`${root}/apps/web/index.html`,threadMove:`${root}/tests/e2e/thread-move-fixture.tsx`,sidebarMenu:`${root}/tests/e2e/sidebar-shared-menu-fixture.tsx`}}}});
 const manifest=JSON.parse(await readFile(`${dist}/.vite/manifest.json`,'utf8'));
 function fixture(entry){
  const [key]=Object.entries(manifest).find(([,item])=>item.isEntry&&item.src?.endsWith(entry));
  const css=new Set(),seen=new Set();
  function collect(key){if(seen.has(key))return;seen.add(key);const item=manifest[key];for(const file of item.css??[])css.add(file);for(const dep of item.imports??[])collect(dep);}
  collect(key);
  return `<!doctype html><html lang="en" data-theme="dark"><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>Synthetic thread evidence</title>${[...css].map(file=>`<link rel="stylesheet" href="/${file}">`).join('')}</head><body><div id="root" style="height:100dvh"></div><script type="module" src="/${manifest[key].file}"></script></body></html>`;
 }
 const snapshot=shellSnapshot();snapshot.settings.preferences={projectOrder:'manual',projectGrouping:false,showWorkingSection:false};
 const server=createServer(async(req,res)=>{
  try{
   const path=new URL(req.url,`http://127.0.0.1:${port}`).pathname;
   if(path.startsWith('/api/')){
    let text='';for await(const chunk of req)text+=chunk;
    return await shellRoute({request:()=>({url:()=>`http://127.0.0.1:${port}${req.url}`,postDataJSON:()=>text?JSON.parse(text):{}}),fulfill:async({json,body,contentType,status=200})=>{res.statusCode=status;res.setHeader('Content-Type',contentType??'application/json');res.end(json===undefined?body??'':JSON.stringify(json));}},snapshot,false);
   }
   if(path==='/capture/sidebar-menu'||path==='/capture/thread-move'){
    res.setHeader('Content-Type','text/html');return res.end(fixture(path.endsWith('sidebar-menu')?'sidebar-shared-menu-fixture.tsx':'thread-move-fixture.tsx'));
   }
   const file=path==='/'||path==='/audit-app'?resolve(dist,'index.html'):resolve(dist,'.'+path);
   if(!file.startsWith(dist+'/'))throw Error('Outside evidence build');
   let bytes;try{bytes=await readFile(file);}catch{res.statusCode=404;res.setHeader('Content-Type','text/plain');return res.end('Not found');}
   const mime={'.html':'text/html','.js':'text/javascript','.css':'text/css','.svg':'image/svg+xml','.woff2':'font/woff2','.png':'image/png'};
   res.setHeader('Content-Type',mime[extname(file)]??'application/octet-stream');
   if(extname(file)==='.html')bytes=Buffer.from(bytes.toString().replace('</head>',`<script>${shellInit}</script></head>`));
   res.end(bytes);
  }catch(error){res.statusCode=500;res.end(String(error));console.error(error);}
 });
 await new Promise((accept,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',accept);});
 return {base:`http://127.0.0.1:${port}`,close:()=>new Promise(resolve=>{server.closeAllConnections();server.close(resolve);})};
}
