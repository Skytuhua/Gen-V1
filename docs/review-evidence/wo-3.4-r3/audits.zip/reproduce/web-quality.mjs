import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {spawn,execFileSync} from 'node:child_process';
import {startHost} from './static-host.mjs';
import assert from 'node:assert/strict';

const root=process.env.AUDIT_ROOT??'/home/box/work/Gen-V1-wo-3-4',name=process.env.AUDIT_NAME??'head',out=process.env.AUDIT_OUT??'/home/box/gen-company/ledger/WO-3/qa-r3-3.4';
const require=createRequire(`${root}/package.json`),audit=createRequire('/tmp/wo-3-118-audit-tools/package.json');
const {chromium}=require('@playwright/test'),AxeBuilder=audit('@axe-core/playwright');
const lighthouse=(await import(pathToFileURL(audit.resolve('lighthouse')))).default;
const launcher=await import(pathToFileURL(audit.resolve('chrome-launcher')));
const head=process.env.AUDIT_SOURCE_SHA??execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim();
const result={head,main:'d72030013715ec94d023195d852562d7d34bc4f4',commands:[],axe:[],layout:[],motion:[],lighthouse:[],errors:[],watchers:false};
let host,browser;
async function save(name,value){await writeFile(`${out}/web-quality/${name}.json`,JSON.stringify(value,null,2));}
async function run(args,name,env={}){
 const log=await import('node:fs').then(fs=>fs.createWriteStream(`${out}/logs/${name}.log`));
 return await new Promise((resolve,reject)=>{
  const child=spawn('pnpm',args,{cwd:root,env:{...process.env,COREPACK_HOME:`${process.env.HOME}/.cache/corepack`,...env},stdio:['ignore','pipe','pipe']});child.stdout.pipe(log);child.stderr.pipe(log);
  const timer=setTimeout(()=>child.kill('SIGTERM'),180000);
  child.on('error',reject);child.on('close',exitCode=>{clearTimeout(timer);log.end();result.commands.push({name,args,exitCode});resolve(exitCode);});
 });
}
function cls(entries){let worst=0,current=0,first=0,last=0;for(const e of entries.filter(e=>!e.hadRecentInput)){if(e.startTime-last>1000||e.startTime-first>5000){current=0;first=e.startTime;}current+=e.value;last=e.startTime;worst=Math.max(worst,current);}return worst;}
try{
 host=await startHost(root,name,name==='head'?5704:5714);browser=await chromium.launch({headless:true});
 for(const screen of name==='head'?['app-shell','sidebar-menu']:[]){
  await run(['capture:ui','--',`--screens=${screen}`,'--max-strips=16','--out',`${out}/captures/${screen}`],`capture-${screen}`,{BASE_URL:host.base});
 }
 for(const width of [375,768,1440]){
  const context=await browser.newContext({viewport:{width,height:1000},reducedMotion:'no-preference'}),page=await context.newPage();
  await page.addInitScript(()=>{window.shifts=[];new PerformanceObserver(list=>{for(const e of list.getEntries())window.shifts.push({value:e.value,startTime:e.startTime,hadRecentInput:e.hadRecentInput});}).observe({type:'layout-shift',buffered:true});});
  await page.goto(host.base+'/');await page.locator('.composer').waitFor({timeout:20000});await page.evaluate(()=>document.fonts.ready);
  for(const state of ['default','menu']){
   if(state==='menu'){
    const open=page.getByRole('button',{name:'Open navigation',exact:true});if(await open.isVisible())await open.click();
    await page.evaluate(()=>{window.focusTrace=[];document.addEventListener('focusin',e=>window.focusTrace.push({at:performance.now(),target:e.target.getAttribute('aria-label')??e.target.className}));});
    await page.getByRole('button',{name:'Options for Audit the workspace',exact:true}).click();
    try{await page.getByRole('menuitem',{name:'Move to top',exact:true}).waitFor({timeout:2500});}
    catch(error){
     const diagnostic=await page.evaluate(()=>({menuPresent:!!document.querySelector('[role="menu"]'),sidebarOpen:document.querySelector('.sidebar')?.classList.contains('sidebar-open'),active:document.activeElement?.getAttribute('aria-label'),focusTrace:window.focusTrace}));
     result.axe.push({width,state,status:'failed',error:String(error),diagnostic});await page.screenshot({path:`${out}/captures/actual-app-${width}-menu-failed.png`,fullPage:true});continue;
    }
   }
   const scan=await new AxeBuilder({page}).withTags(['wcag2a','wcag2aa','wcag21a','wcag21aa','wcag22aa']).analyze();await save(`axe-${width}-${state}`,scan);
   const geometry=await page.evaluate(()=>({innerWidth,scrollWidth:document.documentElement.scrollWidth}));
   result.axe.push({width,state,status:scan.violations.length?'failed':'passed',violations:scan.violations.map(v=>({id:v.id,impact:v.impact,nodes:v.nodes.map(n=>({target:n.target,html:n.html,failureSummary:n.failureSummary}))})),incomplete:scan.incomplete.map(a=>a.id),geometry});
   await page.screenshot({path:`${out}/captures/actual-app-${width}-${state}.png`,fullPage:true});
  }
  const entries=await page.evaluate(()=>window.shifts);result.layout.push({width,kind:'full-app-navigation',cls:cls(entries),entries});await context.close();
 }
 for(const width of name==='head'?[768,1024,1440]:[]){
  const context=await browser.newContext({viewport:{width,height:1000},reducedMotion:'no-preference'}),page=await context.newPage();
  await page.addInitScript(()=>{window.shifts=[];window.animations=[];new PerformanceObserver(list=>{for(const e of list.getEntries())window.shifts.push({value:e.value,startTime:e.startTime,hadRecentInput:e.hadRecentInput});}).observe({type:'layout-shift',buffered:true});const native=Element.prototype.animate;Element.prototype.animate=function(frames,options){const a=native.call(this,frames,options);if(this.matches('.sidebar-thread-row')){a.pause();window.animations.push(a);}return a;};});
  await page.goto(host.base+'/capture/thread-move');await page.getByRole('button',{name:'Options for Thread 4',exact:true}).waitFor();await page.evaluate(()=>document.fonts.ready);
  await page.evaluate(()=>{window.shifts=[];});const before=await page.locator('main').boundingBox();
  for(const edge of ['top','bottom']){
   await page.evaluate(()=>{window.animations=[];});await page.getByRole('button',{name:'Options for Thread 4',exact:true}).click();await page.getByRole('menuitem',{name:`Move to ${edge}`,exact:true}).click();
   const timing=await page.evaluate(()=>window.animations.map(a=>({timing:a.effect.getTiming(),frames:a.effect.getKeyframes(),id:a.effect.target.dataset.threadId})));assert.equal(timing.length,edge==='top'?4:6);
   const frames=[];const box=await page.locator('.thread-flat-list').boundingBox();
   for(const ms of [0,90,180]){
    await page.evaluate(async ms=>{for(const a of window.animations){a.pause();a.currentTime=ms;}await new Promise(resolve=>requestAnimationFrame(resolve));},ms);
    const file=`${out}/captures/move-${edge}-${width}-${ms}ms.png`;await page.screenshot({path:file,clip:{x:0,y:Math.floor(box.y)-8,width,height:Math.ceil(box.height)+16},animations:'allow'});frames.push({ms,file});
   }
   result.motion.push({width,edge,timing,frames});await page.evaluate(()=>window.animations.forEach(a=>a.finish()));await page.waitForTimeout(50);
  }
  const after=await page.locator('main').boundingBox();assert.deepEqual(before,after);const entries=await page.evaluate(()=>window.shifts);result.layout.push({width,kind:'pointer-thread-moves',cls:cls(entries),raw:entries.reduce((s,e)=>s+e.value,0),entries,before,after});await context.close();
 }
 await browser.close();browser=null;
 for(const width of [375,1440]){
  let chrome;
  try{
   chrome=await launcher.launch({chromePath:chromium.executablePath(),chromeFlags:['--headless','--no-sandbox','--disable-dev-shm-usage']});
   const auditRun=await lighthouse(host.base+'/',{port:chrome.port,output:['json','html'],logLevel:'error',onlyCategories:['performance','accessibility','best-practices','seo'],formFactor:width===375?'mobile':'desktop',screenEmulation:{mobile:width===375,width,height:1000,deviceScaleFactor:1,disabled:false}});
   await writeFile(`${out}/web-quality/lighthouse-${width}.json`,auditRun.report[0]);await writeFile(`${out}/web-quality/lighthouse-${width}.html`,auditRun.report[1]);
   result.lighthouse.push({width,throttling:'Lighthouse default simulated',scores:Object.fromEntries(Object.entries(auditRun.lhr.categories).map(([k,v])=>[k,Math.round(v.score*100)])),failedAudits:Object.values(auditRun.lhr.audits).filter(a=>a.score!==null&&a.score<1).map(a=>({id:a.id,title:a.title,score:a.score,displayValue:a.displayValue}))});
  }finally{await chrome?.kill();}
 }
}catch(error){result.errors.push(String(error.stack??error));console.error(error);}
finally{await browser?.close();await host?.close();}
result.exitCode=result.errors.length||result.commands.some(c=>c.exitCode!==0)||result.axe.some(a=>a.status==='failed')||result.lighthouse.some(l=>Object.values(l.scores).some(score=>score<90))?1:0;
await save('results',result);console.log(JSON.stringify({head,commands:result.commands,axe:result.axe.map(a=>({width:a.width,state:a.state,status:a.status,violations:a.violations?.map(v=>v.id)})),layout:result.layout.map(l=>({width:l.width,kind:l.kind,cls:l.cls})),lighthouse:result.lighthouse,errors:result.errors,exitCode:result.exitCode},null,2));process.exitCode=result.exitCode;
