import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
import { writeFile, mkdir } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import assert from 'node:assert/strict';

const root='/home/box/work/Gen-V1-wo-3-4', out='/home/box/gen-company/ledger/WO-3/qa-r2-3.4';
const require=createRequire(`${root}/package.json`), auditRequire=createRequire('/tmp/wo-3-118-audit-tools/package.json');
const {chromium}=require('@playwright/test'), AxeBuilder=auditRequire('@axe-core/playwright');
const lighthouse=(await import(pathToFileURL(auditRequire.resolve('lighthouse')))).default;
const launcher=await import(pathToFileURL(auditRequire.resolve('chrome-launcher')));
const head=execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim();
const base='http://127.0.0.1:5704', result={head,axe:[],layout:[],motion:[],lighthouse:[],errors:[]};
await mkdir(`${out}/captures/motion`,{recursive:true});
const browser=await chromium.launch({headless:true});
async function newPage(options){const context=await browser.newContext(options);return context.newPage();}
async function save(name,data){await writeFile(`${out}/metrics/${name}.json`,JSON.stringify(data,null,2));}
async function install(page,paused=false){
  await page.addInitScript(paused=>{
    window.rowAnimations=[];window.rowRecords=[];window.layoutEntries=[];
    new PerformanceObserver(list=>{
      for(const e of list.getEntries())window.layoutEntries.push({value:e.value,startTime:e.startTime,hadRecentInput:e.hadRecentInput,
        sources:(e.sources??[]).map(source=>({target:source.node?.className,previousRect:source.previousRect.toJSON(),currentRect:source.currentRect.toJSON()}))});
    }).observe({type:'layout-shift',buffered:true});
    const animate=Element.prototype.animate;
    Element.prototype.animate=function(frames,options){
      const animation=animate.call(this,frames,options);
      if(this.matches('.sidebar-thread-row')){
        if(paused)animation.pause();
        window.rowAnimations.push(animation);
        window.rowRecords.push({id:this.dataset.threadId,timing:animation.effect.getTiming(),frames:animation.effect.getKeyframes(),live:this.getAnimations().includes(animation)});
      }return animation;
    };
  },paused);
}
async function ready(page,path='/capture/thread-move'){
  page.setDefaultTimeout(15000);await page.goto(base+path);await page.locator('.thread-item').first().waitFor();await page.evaluate(()=>document.fonts.ready);
}
async function move(page,edge,key){
  await page.getByRole('button',{name:'Options for Thread 4',exact:true}).click();
  const item=page.getByRole('menuitem',{name:`Move to ${edge}`,exact:true});
  if(key){await item.focus();await page.keyboard.press(key);}else await item.click();
  await page.getByRole('menu').waitFor({state:'detached'});
}
function cls(entries){
  let max=0,sum=0,first=0,last=0;
  for(const e of entries.filter(e=>!e.hadRecentInput)){
    if(e.startTime-last>1000||e.startTime-first>5000){sum=0;first=e.startTime;}
    sum+=e.value;last=e.startTime;max=Math.max(max,sum);
  }return max;
}
try{
  for(const width of [375,768,1440]){
    const page=await newPage({viewport:{width,height:1000},reducedMotion:'no-preference'});
    await install(page);await page.goto(base+'/audit-app');await page.locator('.composer').waitFor();await page.evaluate(()=>document.fonts.ready);
    for(const state of ['default','menu']){
      if(width===375&&state==='menu'){
        result.axe.push({width,state,status:'failed',violations:[],overflow:null,
          error:'Actual-app phone menu probe timed out after clicking thread options; see web-quality-mobile-menu-timeout.log. State capture uses the separately named sidebar-menu fixture.'});
        continue;
      }
      if(state==='menu'){
        const open=page.getByRole('button',{name:'Open navigation',exact:true});if(await open.isVisible())await open.click();
        await page.getByRole('button',{name:'Options for Audit the workspace',exact:true}).click();
        await page.getByRole('menuitem',{name:'Move to top',exact:true}).waitFor();
      }
      const axe=await new AxeBuilder({page}).withTags(['wcag2a','wcag2aa','wcag21a','wcag21aa','wcag22aa']).analyze();
      await save(`axe-${width}-${state}`,axe);
      const overflow=await page.evaluate(()=>({viewport:innerWidth,scrollWidth:document.documentElement.scrollWidth}));
      result.axe.push({width,state,violations:axe.violations.map(v=>({id:v.id,impact:v.impact,nodes:v.nodes.length,description:v.description})),incomplete:axe.incomplete.length,overflow});
      await page.screenshot({path:`${out}/captures/audited-${state}-${width}.png`,fullPage:true});
      console.log('axe',width,state,'violations',axe.violations.length,'incomplete',axe.incomplete.length);
    }
    await page.keyboard.press('Escape');await page.waitForTimeout(300);
    const entries=await page.evaluate(()=>window.layoutEntries);result.layout.push({kind:'production-bundled-navigation',width,cls:cls(entries),entries});
    await page.close();
  }
  for(const width of [768,1024,1440]){
    const page=await newPage({viewport:{width,height:1000},reducedMotion:'no-preference'});await install(page);await ready(page);
    await page.waitForTimeout(350);await page.evaluate(()=>{window.layoutEntries=[];});
    const initial=await page.locator('main').boundingBox();await move(page,'top');await page.waitForTimeout(300);
    const entries=await page.evaluate(()=>window.layoutEntries), final=await page.locator('main').boundingBox();
    const rows=await page.evaluate(()=>window.rowRecords);assert.equal(rows.length,4);assert.deepEqual(initial,final);
    result.layout.push({kind:'pointer-thread-move',width,cls:cls(entries),rawShiftValue:entries.reduce((sum,e)=>sum+e.value,0),initial,final,entries});
    console.log('CLS',width,cls(entries),'raw',entries.reduce((sum,e)=>sum+e.value,0));await page.close();
  }
  const page=await newPage({viewport:{width:1440,height:1000},reducedMotion:'no-preference'});await install(page,true);await ready(page);
  for(const edge of ['top','bottom']){
    await page.evaluate(()=>{window.rowAnimations=[];window.rowRecords=[];});await move(page,edge);await page.mouse.move(1200,900);await page.waitForTimeout(150);
    const records=await page.evaluate(()=>window.rowRecords);assert.equal(records.length,edge==='top'?4:6);
    for(const record of records){assert.equal(record.timing.duration,180);assert.equal(record.timing.delay,0);assert.equal(record.timing.easing,'cubic-bezier(0.4, 0, 0.2, 1)');}
    const bounds=await page.locator('.thread-flat-list').boundingBox();
    const clip={x:0,y:Math.floor(bounds.y)-8,width:1440,height:Math.ceil(bounds.height)+16},frames=[];
    for(const ms of edge==='top'?[0,20,45,70,90,120,150,180]:[0,90,180]){
      const geometry=await page.evaluate(async ms=>{for(const a of window.rowAnimations){a.pause();a.currentTime=ms;}await new Promise(resolve=>requestAnimationFrame(resolve));
        return [...document.querySelectorAll('.thread-flat-list>.sidebar-thread-row')].map(node=>({id:node.dataset.threadId,y:node.getBoundingClientRect().y}));},ms);
      const file=`${out}/captures/motion/${edge}-${String(ms).padStart(3,'0')}ms.png`;
      await page.screenshot({path:file,clip,animations:'allow'});frames.push({ms,file,geometry});
    }
    result.motion.push({edge,width:1440,records,frames});await page.evaluate(()=>window.rowAnimations.forEach(a=>a.finish()));await page.waitForTimeout(50);
  }await page.close();
  for(const policy of ['reduce','keyboard']){
    const page=await newPage({viewport:{width:1440,height:1000},reducedMotion:policy==='reduce'?'reduce':'no-preference'});await install(page);await ready(page);
    await move(page,'top',policy==='keyboard'?'Enter':undefined);assert.equal(await page.evaluate(()=>window.rowRecords.length),0);
    result.motion.push({policy,width:1440,rowAnimations:0});await page.close();
  }
  const context=await browser.newContext({viewport:{width:1440,height:1000},reducedMotion:'no-preference',recordVideo:{dir:`${out}/captures/video-raw`,size:{width:1440,height:1000}}});
  const videoPage=await context.newPage();await install(videoPage);await ready(videoPage);await videoPage.waitForTimeout(650);
  await videoPage.getByRole('button',{name:'Options for Thread 4',exact:true}).click();await videoPage.waitForTimeout(300);
  await videoPage.getByRole('menuitem',{name:'Move to top',exact:true}).click();await videoPage.waitForTimeout(1500);
  const video=videoPage.video();await context.close();await video.saveAs('/home/box/gen-company/ledger/WO-3/before-after/3.4-after.webm');
}catch(error){result.errors.push(String(error.stack??error));console.error(error);}
finally{await browser.close();await save('web-quality',result);}

for(const width of [375,1440]){
  let chrome;
  try{
    chrome=await launcher.launch({chromePath:chromium.executablePath(),chromeFlags:['--headless','--no-sandbox','--disable-dev-shm-usage']});
    const run=await lighthouse(base+'/audit-app',{port:chrome.port,output:['json','html'],logLevel:'error',onlyCategories:['performance','accessibility','best-practices','seo'],
      formFactor:width===375?'mobile':'desktop',screenEmulation:{mobile:width===375,width,height:1000,deviceScaleFactor:1,disabled:false},throttlingMethod:'provided'});
    await writeFile(`${out}/metrics/lighthouse-${width}.json`,run.report[0]);await writeFile(`${out}/metrics/lighthouse-${width}.html`,run.report[1]);
    const categories=Object.fromEntries(Object.entries(run.lhr.categories).map(([key,category])=>[key,Math.round(category.score*100)]));
    result.lighthouse.push({width,categories,runtimeError:run.lhr.runtimeError,failedAudits:Object.values(run.lhr.audits).filter(a=>a.score!==null&&a.score<1).map(a=>({id:a.id,title:a.title,score:a.score,displayValue:a.displayValue}))});
    console.log('Lighthouse',width,categories);
  }catch(error){result.errors.push(String(error.stack??error));console.error(error);}finally{await chrome?.kill();}
}
result.auditExitCode=result.errors.length||result.axe.some(a=>a.status==='failed'||a.violations.length||a.overflow?.scrollWidth>a.overflow?.viewport)||result.lighthouse.some(a=>Object.values(a.categories).some(score=>score<90))?1:0;
await save('web-quality',result);console.log('Audit exit:',result.auditExitCode);process.exitCode=result.auditExitCode;
