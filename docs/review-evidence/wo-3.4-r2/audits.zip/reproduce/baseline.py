from pathlib import Path
import subprocess, os, json, tarfile, io

root=Path('/home/box/work/Gen-V1-wo-3-4')
out=Path('/home/box/gen-company/ledger/WO-3/qa-r2-3.4/baseline')
specs=Path('/home/box/work/base-failing-files.txt').read_text().splitlines()
env={**os.environ,'COREPACK_HOME':str(Path.home()/'.cache/corepack')}
results={}
for name,ref in [('head','HEAD'),('main','d72030013715ec94d023195d852562d7d34bc4f4')]:
    sha=subprocess.check_output(['git','rev-parse',ref],cwd=root,text=True).strip()
    checkout=Path('/tmp')/f'wo-3-118-r2-baseline-{name}'
    checkout.mkdir(exist_ok=True)
    archive=subprocess.check_output(['git','archive',sha],cwd=root)
    with tarfile.open(fileobj=io.BytesIO(archive)) as source:source.extractall(checkout,filter='data')
    (checkout/'node_modules').symlink_to((root/'node_modules').resolve(),target_is_directory=True)
    command=['pnpm','exec','vitest','run',*specs,'--maxWorkers=1','--configLoader','runner','--reporter=default','--reporter=json',f'--outputFile={out}/{name}.json']
    print(name,sha,'running',len(specs),'known baseline files',flush=True)
    with (out/f'{name}.log').open('w') as log:
        run=subprocess.run(command,cwd=checkout,env=env,stdout=log,stderr=subprocess.STDOUT)
    report=json.loads((out/f'{name}.json').read_text())
    failed=set()
    for file in report['testResults']:
        relative=Path(file['name']).relative_to(checkout).as_posix()
        if file['status']=='failed' and not file.get('assertionResults'):failed.add(relative+' :: [file error]')
        for test in file.get('assertionResults',[]):
            if test['status']=='failed':failed.add(relative+' :: '+test['fullName'])
    results[name]={'sha':sha,'exitCode':run.returncode,'testFiles':report.get('numTotalTestSuites'),
        'totalTests':report['numTotalTests'],'failedTests':report['numFailedTests'],'passedTests':report['numPassedTests'],'failedIdentities':sorted(failed)}
    print(name,'exit',run.returncode,'failed',report['numFailedTests'],'passed',report['numPassedTests'],flush=True)
new=set(results['head']['failedIdentities'])-set(results['main']['failedIdentities'])
results['comparison']={'newFailedIdentities':sorted(new),'newFailureCount':len(new),'knownBaselineFileCount':len(specs)}
(out/'comparison.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results['comparison']),flush=True)
