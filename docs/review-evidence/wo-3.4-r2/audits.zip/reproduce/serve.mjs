import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
import { readFile, realpath } from 'node:fs/promises';
import { resolve, extname } from 'node:path';

const root = '/home/box/work/Gen-V1-wo-3-4';
const require = createRequire(`${root}/package.json`);
const { createServer, build } = await import(pathToFileURL(require.resolve('vite')));
const { shellSnapshot, shellRoute, shellInit } = await import(pathToFileURL(`${root}/scripts/capture-ui/shell-api.ts`));
const dist = '/tmp/wo-3-118-r2-production';
await build({ configFile: `${root}/vite.config.ts`, configLoader: 'runner', root: `${root}/apps/web`,
  cacheDir: '/tmp/wo-3-118-r2-build-cache', build: { outDir: dist, emptyOutDir: true } });
const snapshot = shellSnapshot();
snapshot.settings.preferences = { projectOrder: 'manual', projectGrouping: false, showWorkingSection: false };
const plugin = {
  name: 'round-2-synthetic-evidence-host',
  transformIndexHtml: html => html.replace('</head>', `<script>${shellInit}</script></head>`),
  configureServer(server) {
    server.middlewares.use(async (req, res, next) => {
      try {
        const path = new URL(req.url, 'http://127.0.0.1:5704').pathname;
        if (path.startsWith('/api/')) {
          let body = ''; for await (const chunk of req) body += chunk;
          const route = {
            request: () => ({ url: () => `http://127.0.0.1:5704${req.url}`, postDataJSON: () => body ? JSON.parse(body) : {} }),
            fulfill: async ({ json, body, contentType, status = 200 }) => {
              res.statusCode = status; res.setHeader('Content-Type', contentType ?? 'application/json');
              res.end(json === undefined ? body ?? '' : JSON.stringify(json));
            },
          };
          return await shellRoute(route, snapshot, false);
        }
        if (path === '/audit-app' || path.startsWith('/assets/')) {
          const file = path === '/audit-app' ? resolve(dist, 'index.html') : resolve(dist, '.' + path);
          if (!file.startsWith(dist + '/')) throw Error('Asset outside build');
          let bytes = await readFile(file);
          if (path === '/audit-app') bytes = Buffer.from(bytes.toString().replace('</head>', `<script>${shellInit}</script></head>`));
          const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.woff2': 'font/woff2', '.svg': 'image/svg+xml', '.png': 'image/png' };
          res.setHeader('Content-Type', mime[extname(file)] ?? 'application/octet-stream'); return res.end(bytes);
        }
        const fixture = path === '/capture/thread-move' ? 'thread-move-fixture.tsx' : path === '/capture/sidebar-menu' ? 'sidebar-shared-menu-fixture.tsx' : null;
        if (!fixture) return next();
        const html = `<!doctype html><html lang="en" data-theme="dark"><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>Thread move evidence fixture</title></head><body><div id="root" style="height:100dvh"></div><script type="module" src="/@fs/${root}/tests/e2e/${fixture}"></script></body></html>`;
        res.setHeader('Content-Type', 'text/html'); res.end(await server.transformIndexHtml(req.url, html));
      } catch (error) { console.error(error); res.statusCode = 500; res.end(String(error)); }
    });
  },
};
const server = await createServer({ configFile: `${root}/tests/e2e/thread-move.vite.config.ts`, configLoader: 'runner',
  root: `${root}/apps/web`, cacheDir: '/tmp/wo-3-118-r2-vite-cache', plugins: [plugin],
  server: { host: '127.0.0.1', port: 5704, strictPort: true, proxy: {},
    fs: { allow: [root, await realpath(`${root}/node_modules`)] } } });
await server.listen();
console.log('READY http://127.0.0.1:5704; production audit route /audit-app; synthetic host data only.');
process.on('SIGTERM', async () => { await server.close(); process.exit(0); });
