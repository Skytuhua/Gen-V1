from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageChops
import json, subprocess, hashlib, shutil, zipfile

root=Path('/home/box/work/Gen-V1-wo-3-4')
ledger=Path('/home/box/gen-company/ledger/WO-3')
out=ledger/'qa-r2-3.4'
packet=root/'docs/review-evidence/wo-3.4-r2'
packet.mkdir(parents=True,exist_ok=True)
quality=json.loads((out/'metrics/web-quality.json').read_text())
manifest=json.loads((out/'captures/ui/manifest.json').read_text())
baseline=json.loads((out/'baseline/comparison.json').read_text())
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',18)
hashes={}
for action in [m for m in quality['motion'] if 'edge' in m]:
    images=[Image.open(item['file']).convert('RGB') for item in action['frames']]
    deltas=[max(x[1] for x in ImageChops.difference(a,b).getextrema()) for a,b in zip(images,images[1:])]
    assert all(d>0 for d in deltas),deltas
    unique=[hashlib.sha256(image.tobytes()).hexdigest() for image in images]
    assert len(set(unique))==len(images)
    band=images[0].height+44
    strip=Image.new('RGB',(1440,band*len(images)),'#111318')
    draw=ImageDraw.Draw(strip)
    for i,(image,frame) in enumerate(zip(images,action['frames'])):
        draw.text((16,i*band+7),f"Move to {action['edge']}: {frame['ms']} ms / 180 ms",font=font,fill='white')
        strip.paste(image,(0,i*band+36))
    name=f"thread-move-{action['edge']}.png"
    strip.save(packet/name,optimize=True)
    strip.save(out/'captures/motion'/name,optimize=True)
    if action['edge']=='top':strip.save(ledger/'before-after/3.4-strip.png',optimize=True)
    hashes[action['edge']]={'times':[f['ms'] for f in action['frames']],'pixelHashes':unique,'adjacentMaxChannelDelta':deltas}

for width in [375,768,1440]:
    entries=[entry for entry in manifest['entries'] if entry['width']==width]
    assert len(entries)==14 and all(entry['status']=='captured' for entry in entries)
    images=[Image.open(out/'captures/ui'/entry['path']).convert('RGB') for entry in entries]
    tile_w=max(image.width for image in images); tile_h=max(image.height for image in images)+40
    sheet=Image.new('RGB',(tile_w*3,tile_h*((len(images)+2)//3)),'#111318');draw=ImageDraw.Draw(sheet)
    for index,(image,entry) in enumerate(zip(images,entries)):
        x=(index%3)*tile_w;y=(index//3)*tile_h
        draw.text((x+8,y+8),f"{entry['screen']} / {entry['state']} / {width}",font=font,fill='white')
        sheet.paste(image,(x,y+40))
    sheet.save(packet/f'states-{width}.png',optimize=True)

video=ledger/'before-after/3.4-after.webm';gif=ledger/'before-after/3.4-after.gif'
subprocess.run(['/usr/bin/ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(video),'-filter_complex',
    '[0:v]fps=25,scale=1440:-1:flags=lanczos,split[a][b];[a]palettegen=stats_mode=diff[p];[b][p]paletteuse=dither=sierra2_4a:diff_mode=rectangle','-loop','0',str(gif)],check=True)
for name in ['3.4-before.gif','3.4-after.gif','3.4-after.webm']:
    shutil.copyfile(ledger/'before-after'/name,packet/name)
duration=float(json.loads(subprocess.check_output(['/usr/bin/ffprobe','-v','error','-show_entries','format=duration','-of','json',str(video)]))['format']['duration'])
assert 2<=duration<=4
runtime_files=['apps/web/src/ShellSidebar.tsx','apps/web/src/sidebar-thread-move.ts','apps/web/src/sidebar-thread-move.css','apps/web/src/task-motion.tsx','apps/web/src/motion-policy.ts','apps/web/src/App.tsx','apps/web/src/WorkspaceHost.tsx','packages/ui-shell/tokens.css','tests/e2e/thread-move-fixture.tsx','tests/e2e/thread-move.spec.ts']
summary={'measuredHead':quality['head'],'productFixHead':'71101ef2b224014a672a402f492bc4c7fe757182',
    'runtimeSha256':{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in runtime_files},
    'commands':{'typecheck':{'exitCode':0},'lint:ui':{'exitCode':0,'violations':0},'focused-vitest':{'exitCode':0,'passed':21,'failed':0},
        'UI verify script':{'command':'pnpm exec tsx scripts/test-browser.ts --suite thread-move','exitCode':0,'passed':24,'failed':0},
        'old-code regression':{'exitCode':1,'passed':0,'failed':2,'source':'7a7addc9b1122dacda8255c9f971528a8528c73a','reason':'order changes, zero of four expected row animations'},
        'capture:ui':{'exitCode':0,**manifest['totals']},'web-quality':{'exitCode':quality['auditExitCode']}},
    'baseline':baseline,'quality':quality,'stripVerification':hashes,'afterClipSeconds':duration,
    'pr118Checks':json.loads((out/'metrics/pr118-checks.json').read_text()),
    'ciAnnotations':json.loads((out/'metrics/ci-annotations.json').read_text()),
    'limits':['Synthetic data and bundled Chromium; no physical-device or live-provider acceptance.','Full pnpm test not run; only the named 58 baseline files compared.','Axe automated checks and incomplete items do not establish full manual WCAG conformance.','Actual-app phone menu audit failed; do not replace it with the separate fixture captures.','Lighthouse 90+ SEO target and Windows CI remain failed.']}
(packet/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(out/'metrics/summary.json').write_text(json.dumps(summary,indent=2)+'\n')
with zipfile.ZipFile(packet/'audits.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for p in sorted((out/'metrics').glob('*.json')):
        if p.name.startswith(('initial-','second-')) or p.name=='pr116-body-after.json':continue
        archive.write(p,'metrics/'+p.name)
    for p in sorted((out/'metrics').glob('lighthouse-*.html')):archive.write(p,'metrics/'+p.name)
    for name in ['manifest.json','motion.json','motion.md','reduced-motion.json','reduced-motion.md','scope.json','index.md']:
        archive.write(out/'captures/ui'/name,'capture/'+name)
    for name in ['baseline-comparison.log','typecheck.log','lint-ui.log','focused-vitest.log','verify-ui.log','old-code-regression.log','capture-ui.log','web-quality.log','web-quality-initial-harness-failure.log','web-quality-mobile-menu-timeout.log']:
        archive.write(out/'logs'/name,'logs/'+name)
    for name in ['serve.mjs','quality.mjs','baseline.py','packet.py']:
        archive.write(ledger/'scratch/3.4/r2'/name,'reproduce/'+name)
print(json.dumps({'packet':str(packet),'afterClipSeconds':duration,'stripVerification':hashes,'files':{p.name:p.stat().st_size for p in packet.iterdir()}},indent=2))
